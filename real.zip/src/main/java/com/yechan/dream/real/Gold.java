package com.yechan.dream.real;

public class Gold extends PlanType{

	public Gold() {
		
		super("Gold", 49.95, 14.50, 1000, 0.45);
	}

	
}
