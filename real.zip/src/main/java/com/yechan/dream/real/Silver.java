package com.yechan.dream.real;

public class Silver extends PlanType {

	public Silver() {
		
		super("Silver", 29.95, 21.50, 500, 0.54);
	}

	
}
